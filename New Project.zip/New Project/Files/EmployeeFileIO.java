package Files;
import java.io.*;
import java.util.Scanner;
import Entity.*;
import EntityList.EmployeeList;

public class EmployeeFileIO{
	
	public static void readFromFile(String fname,EmployeeList EmployeeList){
		try{
			Scanner sc=new Scanner(new File(fname)); 
			while(sc.hasNextLine()){
				String data[] = sc.nextLine().split(";");

				Double id = Double.parseDouble(data[0]);
				String name = data[1];
				Double age = Double.parseDouble(data[2]);
				String gender = data[3];
				String role = data[4];

				Entity.Employee s = new Entity.Employee(id,name,age,gender,role);
				EmployeeList.insertEmployee(s);
			}
			sc.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read the File");
		}
	}
	
	public static void writeInFile(String line, String fname, boolean append){
		try {
		FileWriter writer = new FileWriter(fname,append);
		writer.write(line+"\n");
		writer.close();
		} catch (IOException e) {
			System.out.println("Cannot Write in File");
		}
	}
	public static void saveEmployeeListInFile(EmployeeList EmployeeList, String fname, boolean append){
		try {
		FileWriter writer = new FileWriter(fname,append);
		Employee Employees[] = EmployeeList.getAllEmployee();
		
		for(int i=0;i<Employees.length;i++){
			if(Employees[i]!=null){
				String line = Employees[i].getId()+";"+
							  Employees[i].getName()+";"+
							  Employees[i].getAge()+";"+
							  Employees[i].getAge()+";"+
							  Employees[i].getRole();
							  
				writer.write(line+"\n");
			}
		}
		
		writer.close();
		} catch (IOException e) {
			System.out.println("Cannot Write in File");
		}
	}
}
