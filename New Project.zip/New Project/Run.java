import GUI.*;
import Entity.*;
import EntityList.*;

public class Run {
    public static void main(String []args){
        new LoginPage();
    }
}
