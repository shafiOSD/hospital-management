package GUI;
import Files.*;
import EntityList.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import GUI.Resource.color.MyColor;

public class Homepage extends JFrame implements ActionListener
{	
	private JPanel panel;
	private JButton btnPatientManager, btnDoctorManager, btnEmployeeManager, logout;
	private JLabel label, bgColor;
	private PatientList patientList;
	private DoctorList doctorList;
	private EmployeeList EmployeeList;
	private LoginPage login;
	private Font font = new Font("Bookman Old Style", Font.BOLD, 15);
	private Font font2 = new Font("Bookman Old Style", Font.BOLD, 30);
	
	public Homepage(LoginPage login, PatientList patientList, DoctorList doctorList, EmployeeList EmployeeList){
		super("Homepage");
		this.login = login;
		this.patientList = patientList;
		this.doctorList = doctorList;
		this.EmployeeList = EmployeeList;
        this.setSize(1300, 700);
		this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		 //Panel Container
		 panel = new JPanel();
		panel.setBounds(700, 80, 500, 500);
		panel.setOpaque(true);
		panel.setBackground(MyColor.pink);
		panel.setLayout(null);
		this.add(panel);

		//Window Icon
        ImageIcon icon = new ImageIcon("GUI/Resource/logo.png"); 
        Image WImage = icon.getImage();
        this.setIconImage(WImage);
		

		//Label
		label = new JLabel("Welcome to Homepage");
		label.setBounds(70,20,400,40);
		label.setFont(font2);
		this.add(label);

		//Buttons
		btnPatientManager = new JButton("Patient Management");
        btnPatientManager.setBounds(120, 100, 240, 60);
        btnPatientManager.setFont(font);
		btnPatientManager.setForeground(Color.WHITE);
		btnPatientManager.setBackground(MyColor.blue);
		btnPatientManager.setFocusable(false);
        btnPatientManager.addActionListener(this);
        this.add(btnPatientManager);
		
		btnDoctorManager = new JButton("Doctor Management");
        btnDoctorManager.setBounds(120, 180, 240, 60);
        btnDoctorManager.setFont(font);
		btnDoctorManager.setForeground(Color.WHITE);
		btnDoctorManager.setBackground(MyColor.blue);
		btnDoctorManager.setFocusable(false);
        btnDoctorManager.addActionListener(this);
        this.add(btnDoctorManager);
		
		btnEmployeeManager = new JButton("Employee Management");
        btnEmployeeManager.setBounds(120, 260, 240, 60);
        btnEmployeeManager.setFont(font);
		btnEmployeeManager.setForeground(Color.WHITE);
		btnEmployeeManager.setBackground(MyColor.blue);
		btnEmployeeManager.setFocusable(false);
        btnEmployeeManager.addActionListener(this);
        this.add(btnEmployeeManager);

		logout = new JButton("Logout");
        logout.setBounds(120, 340, 240, 60);
        logout.setFont(font);
		logout.setForeground(Color.WHITE);
		logout.setBackground(MyColor.darkRed);
		logout.setFocusable(false);
        logout.addActionListener(this);
        this.add(logout);
		
		panel.add(label);
		panel.add(btnPatientManager);
        panel.add(btnDoctorManager);
        panel.add(btnEmployeeManager);
		panel.add(logout);
		
		//Images
        ImageIcon image = new ImageIcon("./GUI/Resource/hospitallogo1.png");
		JLabel background = new JLabel();
		background.setBounds(100, 80, 500, 500);
		background.setIcon(image);
		this.add(background);
		
		//Panel Container
        panel = new JPanel();
		panel.setBounds(700, 80, 500, 500);
		panel.setOpaque(true);
		panel.setBackground(MyColor.pink);
		panel.setLayout(null);
		this.add(panel);
		
		// frame background
        bgColor = new JLabel("");
        bgColor.setOpaque(true);
        bgColor.setBounds(0, 0, 1300, 700);
        bgColor.setBackground(MyColor.white);
		this.add(bgColor);

		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
        if(btnPatientManager == e.getSource()){
			new PatientManagerFrame(this, patientList);
			this.setVisible(false);
		}
		else if(btnDoctorManager == e.getSource()){
			new DoctorManagerFrame(this, doctorList);
			this.setVisible(false);
		}
		else if(btnEmployeeManager == e.getSource()){
			new EmployeeManagerFrame(this, EmployeeList);
			this.setVisible(false);
		}
		else if(logout == e.getSource()){
			int option = JOptionPane.showConfirmDialog(this,"Do you want to logout?");
			if(option == JOptionPane.YES_OPTION){
				this.dispose();
				login.setVisible(true);
			}
		}
    }
}
