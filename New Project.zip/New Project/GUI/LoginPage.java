package GUI;
import Files.*;
import EntityList.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import GUI.Resource.color.MyColor;


public class LoginPage extends JFrame implements ActionListener {
    private JLabel userNameTFLabel, passwordLabel, loginText,bgColor;
    private JPanel panel, logoPanel;
    private JTextField userNameTF;
    private JPasswordField password;
    private JButton loginButton;

    Font font1 = new Font("Bookman Old Style", Font.BOLD, 20);
    Font font2 = new Font("Bookman Old Style", Font.BOLD, 40);

    public LoginPage() {
		
		//Frame
        super("Login page");
        this.setSize(1300, 700);
		this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		//Window Icon
        ImageIcon icon = new ImageIcon("GUI/Resource/logo.png"); 									
        Image WImage = icon.getImage();
        this.setIconImage(WImage);
		
		
		//Hospital Images
        ImageIcon image = new ImageIcon("GUI/Resource/hospitallogo1.png");
		JLabel background = new JLabel();
		background.setBounds(100, 80, 500, 500);
		background.setIcon(image);
		this.add(background);
		
		
		//Login button
		loginButton = new JButton("Login");
        loginButton.setBounds(740, 430, 420, 50);
        loginButton.setFont(font1);
        loginButton.setForeground(Color.WHITE);
		loginButton.setBackground(MyColor.blue);
		loginButton.setFocusable(false);
        loginButton.addActionListener(this);
        this.add(loginButton);
		

        //Panel Container
        panel = new JPanel();
		panel.setBounds(700, 80, 500, 500);
		panel.setOpaque(true);
		panel.setBackground(MyColor.pink);
		panel.setLayout(null);
		this.add(panel);
        

        //Welcome Label
        loginText = new JLabel("Login");
        loginText.setBounds(200, 20, 180, 50);
        loginText.setFont(font2);
        this.add(loginText);
		

        // USER NAME Label
        userNameTFLabel = new JLabel("User Name:");
        userNameTFLabel.setBounds(40, 100, 200, 30);
        userNameTFLabel.setFont(font1);
        this.add(userNameTFLabel);

        // USER NAME TextField
        userNameTF = new JTextField("Shafi");
        userNameTF.setBounds(740, 220, 420, 40);
        userNameTF.setFont(font1);
        this.add(userNameTF);

        // User Password Label
        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(40, 200, 150, 40);
        passwordLabel.setFont(font1);
        this.add(passwordLabel);

        // User Password Password Field
        password = new JPasswordField("1234");
        password.setBounds(740, 325, 420, 40);
        password.setEchoChar('*');
        password.setFont(font1);
        this.add(password);

        panel.add(userNameTFLabel);
        panel.add(passwordLabel);
        panel.add(loginText);
		
		
		// frame background
        bgColor = new JLabel("");
        bgColor.setOpaque(true);
        bgColor.setBounds(0, 0, 1300, 700);
        bgColor.setBackground(Color.WHITE);
		this.add(bgColor);
		
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (loginButton == e.getSource()) {
            String name = userNameTF.getText();
            String pass = String.valueOf(password.getPassword());
    
        try {
            if (name.equals("Shafi") && pass.equals("1234")) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                
                PatientList patientList = new PatientList(100);
                PatientFileIO.readFromFile("files/patientInfo.txt",patientList);

                DoctorList doctorList = new DoctorList(100);
                DoctorFileIO.readFromFile("files/DoctorInfo.txt",doctorList);

                EmployeeList EmployeeList = new EmployeeList(100);
                EmployeeFileIO.readFromFile("files/EmployeeInfo.txt",EmployeeList);

                new Homepage(this, patientList, doctorList, EmployeeList);
    
                userNameTF.setText("");
                password.setText("");
                this.setVisible(false);
				
            }
			
			else{
					JOptionPane.showMessageDialog(this, "Invalid User Name or Password");
				}
        }
        
    
        catch (Exception exp) {
            
            JOptionPane.showMessageDialog(this, "Invalid User Name or Password", 
											  "Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}