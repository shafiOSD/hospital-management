package GUI.Resource.color;

import java.awt.*;

public class MyColor {
    public static Color red = Color.RED;
	public static Color black = Color.BLACK;
    public static Color darkRed = new Color(169, 29, 20);
    public static Color white = Color.WHITE;
    public static Color pink = new Color(179, 122, 146);
    public static Color blue = new Color(136, 172, 190);
    public static Color green1 = new Color(165,182,139);
}